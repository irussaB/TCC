<?php
// Consulta um aluno pelo CPF (usado na recuperação de senha)
header('Content-Type: application/json');
require '../../app/conexao.php';
$pdo = Conexao::conectar();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$json = filter_input(INPUT_GET, 'jsn');
$data = json_decode($json, true);
$cpf = $data['cpf'] ?? '';

if (!$cpf) {
    echo json_encode(null);
    exit;
}

$sql = "select id, nome, cpf from alunos where cpf = ? limit 1;";
$prp = $pdo->prepare($sql);
$prp->execute([$cpf]);
$aluno = $prp->fetch(PDO::FETCH_ASSOC);

echo json_encode($aluno ?: null);
conexao::desconectar();