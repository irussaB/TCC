<?php
header('Content-Type: application/json');
require '../../app/conexao.php';
$pdo = Conexao::conectar();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$json = filter_input(INPUT_GET, 'jsn');
$data = json_decode($json, true);

$id    = $data['id']    ?? null;
$senha = $data['senha'] ?? null;

if (!$id || !$senha) {
    echo json_encode(['ok' => false, 'erro' => 'Dados incompletos']);
    exit;
}

// 🔐 Hasheia a nova senha
$senhaHash = password_hash($senha, PASSWORD_DEFAULT);

$sql = "update alunos set senha = ? where id = ?;";
$prp = $pdo->prepare($sql);
$prp->execute([$senhaHash, $id]);

echo json_encode(['ok' => true]);
Conexao::desconectar();