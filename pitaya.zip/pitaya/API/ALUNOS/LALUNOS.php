<?php
header('Content-Type: application/json');
require '../../app/conexao.php';
$pdo = Conexao::conectar();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$json = filter_input(INPUT_GET, 'jsn');
$data = json_decode($json, true);

$email = $data['email'] ?? '';
$senha = $data['senha'] ?? '';

// 🔍 Busca só pelo email (não dá pra comparar senha direto)
$sql = "select id, nome, email, senha from alunos where email = ? limit 1;";
$prp = $pdo->prepare($sql);
$prp->execute([$email]);
$aluno = $prp->fetch(PDO::FETCH_ASSOC);

if (!$aluno) {
    echo json_encode(null);
    exit;
}

// 🔐 Verifica a senha com password_verify
if (!password_verify($senha, $aluno['senha'])) {
    echo json_encode(null);
    exit;
}

// ✅ Login OK — retorna dados sem a senha
unset($aluno['senha']);
echo json_encode($aluno);
Conexao::desconectar();