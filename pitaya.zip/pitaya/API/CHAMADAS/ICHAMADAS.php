<?php
//header('Content-Type: application/json');
//require '../../app/conexao.php';
//$pdo = Conexao::conectar();
//$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//$json = filter_input(INPUT_GET, 'jsn');
//$data = json_decode($json, true);

// Evita duplicar chamada da mesma matrícula/turma/data
//$del = "delete from chamadas where matricula_id=? and turma_id=? and data=?;";
//$pd = $pdo->prepare($del);
//$pd->execute([$data['matid'] ?? null, $data['turid'] ?? null, $data['data'] ?? null]);

//$sql = "insert into chamadas (matricula_id, turma_id, plano_diario_id, data, status) values (?,?,?,?,?);";
//$prp = $pdo->prepare($sql);
//$prp->execute([
//    $data['matid'] ?? null,
//    $data['turid'] ?? null,
//    $data['plano_diario_id'] ?? null,
//    $data['data'] ?? null,
//    $data['status'] ?? 'presente',
//]);

//echo json_encode(['id' => $pdo->lastInsertId()]);
//Conexao::desconectar();




////header('Content-Type: application/json');
////require '../../app/conexao.php';
////$pdo = Conexao::conectar();
////$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
////$json = filter_input(INPUT_GET, 'jsn');
//$data = json_decode($json, true);

//$matricula_id    = $data['matricula_id'] ?? null;
//$plano_diario_id = $data['plano_diario_id'] ?? null;
//$status          = $data['status'] ?? 'presente';

//if (!$matricula_id || !$plano_diario_id) {
//    echo json_encode(['erro' => 'matricula_id e plano_diario_id são obrigatórios']);
//    exit;
//}

// Se já existir, atualiza o status (evita erro de UNIQUE)
//$sql = "insert into chamadas (matricula_id, plano_diario_id, status)
//        values (?,?,?)
//        on duplicate key update status = values(status);";
//$prp = $pdo->prepare($sql);
//$prp->execute([$matricula_id, $plano_diario_id, $status]);

//echo json_encode(['id' => $pdo->lastInsertId() ?: null, 'ok' => true]);
//Conexao::desconectar();


header('Content-Type: application/json');
require '../../app/conexao.php';
$pdo = Conexao::conectar();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$json = filter_input(INPUT_GET, 'jsn');
$data = json_decode($json, true);

$matricula_id    = $data['matricula_id'] ?? null;
$plano_diario_id = $data['plano_diario_id'] ?? null;
$status          = $data['status'] ?? 'presente';

if (!$matricula_id || !$plano_diario_id) {
    echo json_encode(['erro' => 'matricula_id e plano_diario_id são obrigatórios']);
    exit;
}

// Se já existir, atualiza o status (evita erro de UNIQUE)
$sql = "insert into chamadas (matricula_id, plano_diario_id, status)
        values (?,?,?)
        on duplicate key update status = values(status);";
$prp = $pdo->prepare($sql);
$prp->execute([$matricula_id, $plano_diario_id, $status]);

echo json_encode(['id' => $pdo->lastInsertId() ?: null, 'ok' => true]);
Conexao::desconectar();