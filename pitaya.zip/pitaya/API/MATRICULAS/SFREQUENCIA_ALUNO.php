<?php
// Retorna a frequência de um aluno em cada turma.
// Uso: SFREQUENCIA_ALUNO.php?jsn={"aluno_id":1}
header('Content-Type: application/json');
require '../../app/conexao.php';
$pdo = Conexao::conectar();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$json = filter_input(INPUT_GET, 'jsn');
$data = json_decode($json, true);
$aluno_id = $data['aluno_id'] ?? null;

if (!$aluno_id) { echo json_encode([]); exit; }

$sql = "
select
  t.id              as turmaId,
  t.nome            as turmaNome,
  p.nome            as professorNome,
  m.id              as matriculaId,
  (select count(*)
     from chamadas c
     inner join planos_diarios pd on pd.id = c.plano_diario_id
     where c.matricula_id = m.id
       and pd.turma_id = t.id
  ) as totalTreinos,
  (select count(*)
     from chamadas c
     inner join planos_diarios pd on pd.id = c.plano_diario_id
     where c.matricula_id = m.id
       and pd.turma_id = t.id
       and c.status in ('presente', 'justificada')
  ) as treinosPresentes
from matriculas_turmas mt
inner join matriculas m on m.id = mt.matricula_id
inner join turmas t     on t.id = mt.turma_id
left join professores p on p.id = t.professor_id
where m.aluno_id = ?
order by t.nome;
";

$prp = $pdo->prepare($sql);
$prp->execute([$aluno_id]);
$rows = $prp->fetchall(PDO::FETCH_ASSOC);

// Calcula a porcentagem
foreach ($rows as &$r) {
    $total = (int)$r['totalTreinos'];
    $presentes = (int)$r['treinosPresentes'];
    $r['totalTreinos']    = $total;
    $r['treinosPresentes'] = $presentes;
    $r['frequencia'] = $total > 0 ? round(($presentes / $total) * 100) : 0;
}
unset($r);

echo json_encode($rows);
Conexao::desconectar();