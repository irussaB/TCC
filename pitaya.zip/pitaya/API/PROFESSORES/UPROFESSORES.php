<?php
header('Content-Type: application/json');
require '../../app/conexao.php';
$pdo = Conexao::conectar();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$json = filter_input(INPUT_GET, 'jsn');
$data = json_decode($json, true);

if (!empty($data['senha'])) {
    $senhaHash = password_hash($data['senha'], PASSWORD_DEFAULT);
    $sql = "update professores set nome=?, email=?, telefone=?, senha=? where id=?;";
    $prp = $pdo->prepare($sql);
    $prp->execute([
        $data['nome'] ?? null, $data['email'] ?? null,
        $data['telefone'] ?? null, $senhaHash, $data['id'] ?? null
    ]);
} else {
    $sql = "update professores set nome=?, email=?, telefone=? where id=?;";
    $prp = $pdo->prepare($sql);
    $prp->execute([
        $data['nome'] ?? null, $data['email'] ?? null,
        $data['telefone'] ?? null, $data['id'] ?? null
    ]);
}

echo json_encode(['ok' => true]);
Conexao::desconectar();