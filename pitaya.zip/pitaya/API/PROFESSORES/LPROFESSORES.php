<?php
header('Content-Type: application/json');
require '../../app/conexao.php';
$pdo = Conexao::conectar();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$json = filter_input(INPUT_GET, 'jsn');
$data = json_decode($json, true);

$email = $data['email'] ?? '';
$senha = $data['senha'] ?? '';

// 🔍 Busca só pelo email
$sql = "select id, nome, email, telefone, senha from professores where email = ? limit 1;";
$prp = $pdo->prepare($sql);
$prp->execute([$email]);
$prof = $prp->fetch(PDO::FETCH_ASSOC);

if (!$prof) {
    echo json_encode(null);
    exit;
}

// 🔐 Verifica a senha
if (!password_verify($senha, $prof['senha'])) {
    echo json_encode(null);
    exit;
}

unset($prof['senha']);
echo json_encode($prof);
Conexao::desconectar();