<?php
header('Content-Type: application/json');
require '../../app/conexao.php';
$pdo = Conexao::conectar();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$json = filter_input(INPUT_GET, 'jsn');
$data = json_decode($json, true);

// 🔐 Hasheia a senha
$senhaHash = password_hash($data['senha'] ?? '', PASSWORD_DEFAULT);

$sql = "insert into professores (nome, email, senha, telefone) values (?,?,?,?);";
$prp = $pdo->prepare($sql);
$prp->execute([
    $data['nome'] ?? null,
    $data['email'] ?? null,
    $senhaHash,
    $data['telefone'] ?? null,
]);

echo json_encode(['id' => $pdo->lastInsertId()]);
Conexao::desconectar();