// ── TEMA ──
let cliquesTema = 0, temporizadorTema = null;

function alternarTema() {
  cliquesTema++;
  clearTimeout(temporizadorTema);
  temporizadorTema = setTimeout(() => cliquesTema = 0, 1500);

  if (cliquesTema >= 5) {
    cliquesTema = 0;
    document.body.classList.add('tema-escuro');
    const ativo = document.body.classList.toggle('tema-time');
    document.getElementById('icone-tema').className = ativo ? 'ti ti-flame' : 'ti ti-moon';
    localStorage.setItem('tema', ativo ? 'time' : 'escuro');
    return;
  }

  if (document.body.classList.contains('tema-time')) return;

  const escuro = document.body.classList.toggle('tema-escuro');
  document.getElementById('icone-tema').className = escuro ? 'ti ti-moon' : 'ti ti-sun';
  localStorage.setItem('tema', escuro ? 'escuro' : 'claro');
}

(function () {
  const salvo = localStorage.getItem('tema');
  if (salvo === 'time') {
    document.body.classList.add('tema-escuro', 'tema-time');
  } else if (salvo === 'claro') {
    // nada
  } else {
    document.body.classList.add('tema-escuro');
  }
  document.addEventListener('DOMContentLoaded', function () {
    const ic = document.getElementById('icone-tema');
    if (!ic) return;
    if (salvo === 'time') ic.className = 'ti ti-flame';
    else if (salvo === 'claro') ic.className = 'ti ti-sun';
    else ic.className = 'ti ti-moon';
  });
})();

// ── OLHINHO ──
function toggleSenha() {
  const campo = document.getElementById('senha');
  const icone = document.getElementById('icone-olho');
  const visivel = campo.type === 'text';
  campo.type = visivel ? 'password' : 'text';
  icone.className = visivel ? 'ti ti-eye' : 'ti ti-eye-off';
}

// ── LOGIN (conecta na API) ──
const apiUrlAlunos = 'http://localhost/pitaya/api/ALUNOS/';

function fazerLogin(e) {
  e.preventDefault();
  const email = document.getElementById('email').value.trim().toLowerCase();
  const senha = document.getElementById('senha').value;
  const alerta = document.getElementById('alerta-erro');
  const textoErro = document.getElementById('texto-erro');
  const botao = document.querySelector('.btn-entrar');

  botao.disabled = true;

  fetch(`${apiUrlAlunos}LALUNOS.php?jsn=${encodeURIComponent(JSON.stringify({ email, senha }))}`)
    .then(r => r.json())
    .then(aluno => {
      botao.disabled = false;
      if (aluno) {
        localStorage.setItem('aluno-logado', JSON.stringify(aluno));
        alerta.style.display = 'none';
        window.location.href = 'pages/aluno/perfil/index.html';
      } else {
        textoErro.textContent = 'E-mail ou senha incorretos. Tente novamente.';
        alerta.style.display = 'flex';
        document.getElementById('senha').focus();
      }
    })
    .catch(() => {
      botao.disabled = false;
      textoErro.textContent = 'Não foi possível fazer login agora.';
      alerta.style.display = 'flex';
    });
}

// ═══════════════════════════════════════════════════
//  RECUPERAÇÃO DE SENHA
// ═══════════════════════════════════════════════════
const apiUrlAlunosRec = 'http://localhost/pitaya/api/ALUNOS/';
let alunoRecuperando = null;

function abrirModalRecuperar() {
  // Limpa tudo
  alunoRecuperando = null;
  document.getElementById('rec-cpf').value = '';
  document.getElementById('rec-nome').value = '';
  document.getElementById('rec-cpf-confirmado').value = '';
  document.getElementById('rec-nova-senha').value = '';
  document.getElementById('rec-confirma-senha').value = '';
  document.getElementById('rec-campos-senha').style.display = 'none';
  document.getElementById('btn-confirmar-recuperar').disabled = true;
  const status = document.getElementById('rec-status');
  status.textContent = '';
  status.style.color = 'var(--texto-mudo)';

  document.getElementById('modal-recuperar-senha').classList.add('aberto');
}

function fecharModalRecuperar() {
  document.getElementById('modal-recuperar-senha').classList.remove('aberto');
}

// Busca o aluno assim que o CPF tiver 14 caracteres (***.***.***-**)
document.addEventListener('DOMContentLoaded', () => {
  const campoCpf = document.getElementById('rec-cpf');
  if (!campoCpf) return;

  campoCpf.addEventListener('input', async function () {
    const cpf = this.value.trim();
    const status = document.getElementById('rec-status');

    // Limpa o resultado anterior
    alunoRecuperando = null;
    document.getElementById('rec-campos-senha').style.display = 'none';
    document.getElementById('btn-confirmar-recuperar').disabled = true;

    if (cpf.length < 14) {
      status.textContent = '';
      return;
    }

    status.textContent = 'Consultando...';
    status.style.color = 'var(--texto-mudo)';

    try {
      const r = await fetch(`${apiUrlAlunosRec}RCONSULTAR_ALUNO.php?jsn=${encodeURIComponent(JSON.stringify({ cpf }))}`);
      const aluno = await r.json();

      if (!aluno) {
        status.textContent = '✗ CPF não encontrado no sistema.';
        status.style.color = 'var(--vermelho)';
        return;
      }

      alunoRecuperando = aluno;
      document.getElementById('rec-nome').value = aluno.nome;
      document.getElementById('rec-cpf-confirmado').value = aluno.cpf;
      document.getElementById('rec-campos-senha').style.display = 'flex';
      document.getElementById('btn-confirmar-recuperar').disabled = false;

      status.textContent = '✓ Aluno encontrado. Defina a nova senha.';
      status.style.color = 'var(--verde)';

      // Foca no campo de nova senha
      document.getElementById('rec-nova-senha').focus();

    } catch (err) {
      console.error(err);
      status.textContent = '✗ Erro ao consultar. Tente novamente.';
      status.style.color = 'var(--vermelho)';
    }
  });
});

async function confirmarRecuperacao() {
  if (!alunoRecuperando) { alert('Informe um CPF válido primeiro.'); return; }

  const senha = document.getElementById('rec-nova-senha').value;
  const confirma = document.getElementById('rec-confirma-senha').value;

  if (senha.length < 6) { alert('A senha deve ter no mínimo 6 caracteres.'); return; }
  if (senha !== confirma) { alert('As senhas não são iguais.'); return; }

  const btn = document.getElementById('btn-confirmar-recuperar');
  btn.disabled = true;
  btn.innerHTML = '<i class="ti ti-loader"></i> Salvando...';

  try {
    const r = await fetch(`${apiUrlAlunosRec}USENHA.php?jsn=${encodeURIComponent(JSON.stringify({
      id: alunoRecuperando.id,
      senha: senha
    }))}`);
    const res = await r.json();

    if (res.ok) {
      alert('Senha alterada com sucesso! Faça login com a nova senha.');
      fecharModalRecuperar();
    } else {
      alert('Erro ao alterar a senha: ' + (res.erro || 'desconhecido'));
    }
  } catch (err) {
    console.error(err);
    alert('Erro ao salvar. Verifique a conexão.');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i class="ti ti-check"></i> Confirmar';
  }
}