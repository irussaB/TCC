const apiHorarios = 'http://localhost/pitaya/api/HORARIOS/';
const apiFreq = 'http://localhost/pitaya/api/MATRICULAS/';

const DIAS = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];

function sairAluno() {
  localStorage.removeItem('aluno-logado');
  window.location.href = '../../../index.html';
}

function carregar() {
  const logado = JSON.parse(localStorage.getItem('aluno-logado') || 'null');
  if (!logado) { window.location.href = '../../../index.html'; return; }

  Promise.all([
    fetch(`${apiHorarios}SHORARIOS.php`).then(r => r.json()),
    fetch(`${apiFreq}SFREQUENCIA_ALUNO.php?jsn=${encodeURIComponent(JSON.stringify({ aluno_id: logado.id }))}`).then(r => r.json())
  ])
    .then(([todosHorarios, minhasTurmas]) => {
      const idsMinhasTurmas = minhasTurmas.map(t => Number(t.turmaId));
      const meusHorarios = todosHorarios.filter(h => idsMinhasTurmas.includes(Number(h.turma_id)));

      const cont = document.getElementById('lista-horarios');
      const vazio = document.getElementById('vazio-horarios');

      if (!meusHorarios.length) {
        cont.innerHTML = '';
        vazio.style.display = 'block';
        return;
      }
      vazio.style.display = 'none';

      cont.innerHTML = meusHorarios.map(h => `
        <div class="horario-aluno-card">
          <div class="horario-aluno-topo">
            <div class="horario-aluno-icone"><i class="ti ti-clock"></i></div>
            <div class="horario-aluno-info">
              <div class="horario-aluno-turma">${h.turmaNome}</div>
              <div class="horario-aluno-dia">
                <i class="ti ti-calendar"></i> ${DIAS[h.dia_semana]}
              </div>
            </div>
          </div>

          <div class="horario-aluno-horarios">
            <div class="horario-aluno-hora">
              <span class="horario-aluno-hora-label">Início</span>
              <span class="horario-aluno-hora-valor">${(h.horario_inicio || '').substring(0,5)}</span>
            </div>
            <div class="horario-aluno-hora">
              <span class="horario-aluno-hora-label">Fim</span>
              <span class="horario-aluno-hora-valor fim">${(h.horario_fim || '').substring(0,5)}</span>
            </div>
          </div>
        </div>
      `).join('');
    })
    .catch(err => {
      console.error('Erro ao carregar horários:', err);
      const cont = document.getElementById('lista-horarios');
      const vazio = document.getElementById('vazio-horarios');
      if (cont) cont.innerHTML = '';
      if (vazio) vazio.style.display = 'block';
    });
}

window.onload = carregar;