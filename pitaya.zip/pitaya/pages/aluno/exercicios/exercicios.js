const apiEx = 'http://localhost/pitaya/api/EXERCICIOS/';
const apiCat = 'http://localhost/pitaya/api/CATEGORIAS/';

let exercicios = [], categorias = [], filtro = 'todas';

function sairAluno() {
  localStorage.removeItem('aluno-logado');
  window.location.href = '../../../index.html';
}

function carregar() {
  const logado = JSON.parse(localStorage.getItem('aluno-logado') || 'null');
  if (!logado) { window.location.href = '../../../index.html'; return; }

  Promise.all([
    fetch(`${apiEx}SEXERCICIOS.php`).then(r => r.json()),
    fetch(`${apiCat}SCATEGORIAS.php`).then(r => r.json())
  ]).then(([e, c]) => {
    exercicios = e; categorias = c;
    renderFiltros();
    renderExercicios();
  });
}

function renderFiltros() {
  document.getElementById('filtros-categorias').innerHTML = categorias.map(c =>
    `<button class="chip" onclick="filtrar(${c.id}, this)">${c.nome}</button>`
  ).join('');
}

function renderExercicios() {
  const cont = document.getElementById('exercicios-grid');
  const vazio = document.getElementById('vazio-ex');
  const filtrados = exercicios.filter(e => filtro === 'todas' || e.categoria_id == filtro);
  if (!filtrados.length) {
    cont.innerHTML = '';
    vazio.style.display = 'block';
    return;
  }
  vazio.style.display = 'none';

  cont.innerHTML = filtrados.map(e => `
    <div class="exercicio-card">
      <h4>${e.nome}</h4>
      <p>${e.descricao}</p>
      <span class="badge badge-laranja">${e.categoriaNome}</span>
    </div>
  `).join('');
}

function filtrar(id, btn) {
  filtro = id;
  document.querySelectorAll('.chip').forEach(b => b.classList.remove('selecionado'));
  if (btn) btn.classList.add('selecionado');
  renderExercicios();
}

window.onload = carregar;