const apiFreq = 'http://localhost/pitaya/api/MATRICULAS/';

function sairAluno() {
  localStorage.removeItem('aluno-logado');
  window.location.href = '../../../index.html';
}

function carregar() {
  const logado = JSON.parse(localStorage.getItem('aluno-logado') || 'null');
  if (!logado) { window.location.href = '../../../index.html'; return; }

  fetch(`${apiFreq}SFREQUENCIA_ALUNO.php?jsn=${encodeURIComponent(JSON.stringify({ aluno_id: logado.id }))}`)
    .then(r => r.json())
    .then(turmas => {
      const cont = document.getElementById('lista-turmas');
      const vazio = document.getElementById('vazio-turmas');

      if (!turmas.length) {
        cont.innerHTML = '';
        vazio.style.display = 'block';
        return;
      }
      vazio.style.display = 'none';

      cont.innerHTML = turmas.map(t => `
        <div class="turma-aluno-card">
          <div class="turma-aluno-topo">
            <div class="turma-aluno-icone"><i class="ti ti-ball-basketball"></i></div>
            <div class="turma-aluno-info">
              <div class="turma-aluno-nome">${t.turmaNome}</div>
              <div class="turma-aluno-prof">
                <i class="ti ti-user"></i> Prof. ${t.professorNome || '—'}
              </div>
            </div>
          </div>

          <div class="turma-aluno-progresso-bloco">
            <div class="turma-aluno-progresso-header">
              <span>Frequência</span>
              <span class="turma-aluno-porcentagem">${t.frequencia}%</span>
            </div>
            <div class="turma-aluno-progresso">
              <div class="turma-aluno-progresso-preenchido" style="width:${t.frequencia}%"></div>
            </div>
          </div>

          <div class="turma-aluno-stats">
            <div class="turma-aluno-stat">
              <i class="ti ti-calendar-check"></i>
              <span><strong>${t.totalTreinos}</strong> treinos dados</span>
            </div>
            <div class="turma-aluno-stat">
              <i class="ti ti-check"></i>
              <span><strong>${t.treinosPresentes}</strong> presentes</span>
            </div>
          </div>
        </div>
      `).join('');
    })
    .catch(err => {
      console.error(err);
      document.getElementById('vazio-turmas').style.display = 'block';
    });
}

window.onload = carregar;