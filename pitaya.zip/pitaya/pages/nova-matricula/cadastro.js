const apiUrlAlunos = 'http://localhost/pitaya/api/ALUNOS/';
const apiUrlMatriculas = 'http://localhost/pitaya/api/MATRICULAS/';

// ── CONSTANTES DE VALIDAÇÃO DE ARQUIVO ──
const TIPOS_ACEITOS = ['application/pdf', 'image/png', 'image/jpeg'];
const TAMANHO_MAX = 5 * 1024 * 1024; // 5 MB

// ── VALIDAÇÃO DE CPF ──
function validarCPF(cpf) {
  cpf = cpf.replace(/\D/g, '');
  if (cpf.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(cpf)) return false;

  let soma = 0;
  for (let i = 0; i < 9; i++) soma += parseInt(cpf[i]) * (10 - i);
  let resto = soma % 11;
  let dv1 = resto < 2 ? 0 : 11 - resto;
  if (dv1 !== parseInt(cpf[9])) return false;

  soma = 0;
  for (let i = 0; i < 10; i++) soma += parseInt(cpf[i]) * (11 - i);
  resto = soma % 11;
  let dv2 = resto < 2 ? 0 : 11 - resto;
  if (dv2 !== parseInt(cpf[10])) return false;

  return true;
}

// ── FEEDBACK VISUAL DO CPF (em tempo real) ──
function feedbackCPF(input) {
  const wrapper = input.closest('.form-grupo');
  if (!wrapper) return;

  let icone = wrapper.querySelector('.cpf-feedback');
  if (!icone) {
    icone = document.createElement('small');
    icone.className = 'cpf-feedback';
    icone.style.cssText = 'font-size:11px;margin-top:4px;display:block;';
    wrapper.appendChild(icone);
  }

  const valor = input.value.trim();

  // Ainda não terminou de digitar
  if (valor.length < 14) {
    icone.textContent = '';
    input.style.borderColor = '';
    input.setCustomValidity('');
    return;
  }

  if (validarCPF(valor)) {
    icone.textContent = '✓ CPF válido';
    icone.style.color = 'var(--verde)';
    input.style.borderColor = 'var(--verde)';
    input.setCustomValidity('');
  } else {
    icone.textContent = '✗ CPF inválido';
    icone.style.color = 'var(--vermelho)';
    input.style.borderColor = 'var(--vermelho)';
    input.setCustomValidity('CPF inválido');
  }
}

// ── MÁSCARA DE CEP ──
function mascaraCEP(input) {
  let v = input.value.replace(/\D/g, '');
  v = v.replace(/(\d{5})(\d{1,3})$/, '$1-$2');
  input.value = v;
}

// ── BUSCA DE CEP VIA VIACEP ──
async function buscarCEP() {
  const campoCep = document.getElementById('cep');
  const status = document.getElementById('cep-status');
  const botao = document.getElementById('btn-buscar-cep');

  if (!campoCep || !status) return;

  const cep = campoCep.value.replace(/\D/g, '');

  if (cep.length !== 8) {
    status.textContent = '⚠ Digite um CEP com 8 dígitos (ex: 17000-000)';
    status.style.color = 'var(--amarelo)';
    campoCep.focus();
    return;
  }

  botao.disabled = true;
  botao.innerHTML = '<i class="ti ti-loader"></i> Buscando...';
  status.textContent = 'Consultando ViaCEP...';
  status.style.color = 'var(--texto-mudo)';

  try {
    const resposta = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
    const dados = await resposta.json();

    if (dados.erro) {
      status.textContent = '✗ CEP não encontrado';
      status.style.color = 'var(--vermelho)';
      return;
    }

    document.getElementById('endereco').value = dados.logradouro || '';
    document.getElementById('bairro').value   = dados.bairro     || '';
    document.getElementById('cidade').value   = dados.localidade || '';
    document.getElementById('uf').value       = dados.uf         || '';

    status.textContent = `✓ ${dados.localidade}/${dados.uf} encontrado`;
    status.style.color = 'var(--verde)';

    document.getElementById('numero').focus();

  } catch (err) {
    console.error('Erro ViaCEP:', err);
    status.textContent = '✗ Erro ao consultar o ViaCEP. Verifique sua conexão.';
    status.style.color = 'var(--vermelho)';
  } finally {
    botao.disabled = false;
    botao.innerHTML = '<i class="ti ti-search"></i> Buscar';
  }
}

// ── AUTO-BUSCA CEP QUANDO COMPLETAR 8 DÍGITOS + VALIDAÇÃO DE CPF EM TEMPO REAL ──
document.addEventListener('DOMContentLoaded', () => {
  // Auto-busca CEP
  const campoCep = document.getElementById('cep');
  if (campoCep) {
    campoCep.addEventListener('input', function () {
      const cep = this.value.replace(/\D/g, '');
      if (cep.length === 8) buscarCEP();
    });
  }

  // Validação de CPF em tempo real — aluno
  const cpfAluno = document.getElementById('cpf-aluno');
  if (cpfAluno) {
    cpfAluno.addEventListener('input', function () {
      feedbackCPF(this);
    });
    cpfAluno.addEventListener('blur', function () {
      feedbackCPF(this);
    });
  }

  // Validação de CPF em tempo real — responsável
  const cpfResp = document.getElementById('cpf-resp');
  if (cpfResp) {
    cpfResp.addEventListener('input', function () {
      feedbackCPF(this);
    });
    cpfResp.addEventListener('blur', function () {
      feedbackCPF(this);
    });
  }
});

// ── VALIDAÇÃO DE ARQUIVO ──
function validarArquivo(input, nomeCampo) {
  if (!input.files.length) {
    alert(`Anexe o ${nomeCampo}.`);
    return false;
  }
  const file = input.files[0];
  if (!TIPOS_ACEITOS.includes(file.type)) {
    alert(`${nomeCampo}: só aceita PDF, PNG ou JPG.`);
    return false;
  }
  if (file.size > TAMANHO_MAX) {
    alert(`${nomeCampo}: o arquivo não pode passar de 5 MB.`);
    return false;
  }
  return true;
}

// ── MOSTRA/OCULTA CAMPOS DO RESPONSÁVEL CONFORME IDADE ──
function atualizarSecaoResponsavel() {
  const nasc = document.getElementById('nascimento').value;
  const idade = calcularIdade(nasc);

  const titulo = document.getElementById('titulo-responsavel');
  const labelNome = document.getElementById('label-resp-nome');
  const labelCpf = document.getElementById('label-resp-cpf');
  const labelTel = document.getElementById('label-resp-tel');
  const labelAut = document.getElementById('label-autorizacao');
  const reqAut = document.getElementById('req-autorizacao');

  if (idade !== null && idade >= 18) {
    titulo.textContent = 'Contato de emergência';
    labelNome.innerHTML = 'Nome do contato <span class="req">*</span>';
    labelCpf.innerHTML = 'CPF do contato <span class="req">*</span>';
    labelTel.innerHTML = 'Telefone do contato <span class="req">*</span>';
    labelAut.innerHTML = 'Autorização do responsável (opcional)';
    if (reqAut) reqAut.remove();
  } else {
    titulo.textContent = 'Responsável';
    labelNome.innerHTML = 'Nome do responsável <span class="req">*</span>';
    labelCpf.innerHTML = 'CPF do responsável <span class="req">*</span>';
    labelTel.innerHTML = 'Telefone do responsável <span class="req">*</span>';
    labelAut.innerHTML = 'Autorização do responsável <span class="req" id="req-autorizacao">*</span>';
  }
}

// ── CONVERTE ARQUIVO PARA BASE64 ──
function lerArquivoBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// ── POST JSON ──
function postJSON(url, payload) {
  return fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  }).then(r => r.json());
}

// ── SUBMIT ──
document.getElementById('form-cadastro').addEventListener('submit', async function (event) {
  event.preventDefault();

  // ── Validações ──
  const nascimento = document.getElementById('nascimento').value;
  const idade = calcularIdade(nascimento);
  if (idade === null || idade < 7 || idade > 21) {
    alert('A idade deve estar entre 7 e 21 anos.');
    return;
  }

  const sexo = document.getElementById('sexo').value;
  if (!sexo) { alert('Selecione o sexo (F ou M).'); return; }

  const senha = document.getElementById('senha').value;
  const confirma = document.getElementById('confirma-senha').value;
  if (senha !== confirma) { alert('As senhas devem ser iguais.'); return; }

  const emailAluno = document.getElementById('email-aluno');
  if (!emailValido(emailAluno.value)) { alert('Informe um e-mail válido.'); return; }

  // ── Validação de CPF (aluno e responsável) ──
  const cpfAlunoValor = document.getElementById('cpf-aluno').value;
  if (!validarCPF(cpfAlunoValor)) {
    alert('CPF do aluno inválido. Verifique os dígitos.');
    document.getElementById('cpf-aluno').focus();
    return;
  }

  const cpfRespValor = document.getElementById('cpf-resp').value;
  if (!validarCPF(cpfRespValor)) {
    alert('CPF do responsável/contato inválido. Verifique os dígitos.');
    document.getElementById('cpf-resp').focus();
    return;
  }

  // ── Validação dos documentos ──
  const arquivoMedico = document.getElementById('arquivo-medico');
  if (!validarArquivo(arquivoMedico, 'exame médico')) return;

  const arquivoAutorizacao = document.getElementById('arquivo-autorizacao');
  if (idade < 18) {
    if (!validarArquivo(arquivoAutorizacao, 'autorização do responsável')) return;
  } else if (arquivoAutorizacao.files.length) {
    if (!validarArquivo(arquivoAutorizacao, 'autorização do responsável')) return;
  }

  const obrigatorios = [
    'nome', 'cpf-aluno', 'telefone-aluno', 'peso', 'altura',
    'cep', 'numero', 'endereco', 'bairro', 'cidade', 'uf', 'psf',
    'nome-resp', 'cpf-resp', 'telefone-resp'
  ];
  for (const id of obrigatorios) {
    const el = document.getElementById(id);
    if (!el.value.trim()) { alert('Preencha todos os campos obrigatórios.'); el.focus(); return; }
  }

  // ── Botão de envio ──
  const btn = document.querySelector('#form-cadastro button[type="submit"]');
  const textoOriginal = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '<i class="ti ti-loader"></i> Enviando...';

  try {
    const docMedicoB64 = await lerArquivoBase64(arquivoMedico.files[0]);
    const docAutB64 = arquivoAutorizacao.files.length
      ? await lerArquivoBase64(arquivoAutorizacao.files[0])
      : null;

    const aluno = {
      nome: document.getElementById('nome').value.trim(),
      email: document.getElementById('email-aluno').value.trim(),
      senha: senha,
      cpf: document.getElementById('cpf-aluno').value.trim(),
      sexo: sexo,
      datanasc: nascimento,
      telefone: document.getElementById('telefone-aluno').value.trim(),
      altura: document.getElementById('altura').value,
      peso: document.getElementById('peso').value,
      endereco: document.getElementById('endereco').value.trim(),
      bairro: document.getElementById('bairro').value.trim(),
      numero: document.getElementById('numero').value.trim(),
      cidade: document.getElementById('cidade').value.trim(),
      uf: document.getElementById('uf').value,
      cep: document.getElementById('cep').value.trim(),
      psf: document.getElementById('psf').value.trim(),
      contatoemergencianome: document.getElementById('nome-resp').value.trim(),
      contatoemergenciatelefone: document.getElementById('telefone-resp').value.trim(),
      contatoemergenciacpf: document.getElementById('cpf-resp').value.trim(),
      atestadomedico: docMedicoB64,
      autorizacaoresponsavel: docAutB64
    };

    const resultadoAluno = await postJSON(`${apiUrlAlunos}IALUNOS.php`, aluno);

    if (!resultadoAluno.id) {
      throw new Error(resultadoAluno.erro || 'Erro ao cadastrar aluno');
    }

    const resultadoMat = await postJSON(`${apiUrlMatriculas}IMATRICULAS.php`, {
      aluno_id: resultadoAluno.id,
      data_matricula: new Date().toISOString().slice(0, 10),
      status: 'pendente'
    });

    if (!resultadoMat.id) {
      throw new Error(resultadoMat.erro || 'Erro ao criar matrícula');
    }

    document.getElementById('form-cadastro').style.display = 'none';
    document.getElementById('tela-confirmacao').style.display = 'block';
    window.scrollTo({ top: 0, behavior: 'smooth' });

  } catch (err) {
    console.error('Erro no cadastro:', err);
    alert('Erro ao enviar: ' + err.message);
    btn.disabled = false;
    btn.innerHTML = textoOriginal;
  }
});